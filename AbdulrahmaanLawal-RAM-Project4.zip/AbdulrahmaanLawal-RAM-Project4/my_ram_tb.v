/*
Name: Abdulrahmaan Lawal
RNumber: R111914753
Assignment: Project 4 RAM
*/

`timescale 1ns / 1ps

module my_ram_tb;

	// Inputs
	reg clk;
	reg en;
	reg [4:0] addra;
	reg wea;
	reg [3:0] data_in;
	
	integer i;

	// Outputs
	wire [3:0] data_out;

	// Instantiate the Unit Under Test (UUT)
	my_ram uut (
		.clk(clk), 
		.en(en), 
		.addra(addra), 
		.wea(wea), 
		.data_in(data_in), 
		.data_out(data_out)
	);
	
	 // Clock generation
	always #5 clk = ~clk;

	initial begin
		// Initialize Inputs
		clk = 0;
		en = 0;
		addra = 0;
		wea = 0;
		data_in = 0;

		// Wait 100 ns for global reset to finish
		#20;
		en = 1; // Enable the RAM
		wea = 1; 	  // Enable writing

		for(i = 0; i < 32; i = i+1)begin // for loop to write to all addresses
			addra = i;
			data_in = 15-i; // write vaules F,E,D,C,B,A.....
			#10;
		end

		wea = 0;        // Disable writing

		for (i = 0; i < 32; i = i + 1) begin  // for loop to read all addresses
			 addra = i;
			 #10;
		end
		
        
		// Add stimulus here
		$finish;
	end
	
      
endmodule

