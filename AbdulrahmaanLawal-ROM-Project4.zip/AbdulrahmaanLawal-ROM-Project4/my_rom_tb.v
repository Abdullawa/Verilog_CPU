/*
Name: Abdulrahmaan Lawal
RNumber: R111914753
Assignment: Project 4 ROM
*/

`timescale 1ns/1ps



module my_rom_tb;

    reg clk;
    reg en;
    reg [4:0] addr;
    wire [3:0] data_out;

    integer i;

    // Instantiate the ROM wrapper
    my_rom dut (
        .clk(clk),
        .en(en),
        .addr(addr),
        .data_out(data_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    // Test sequence
    initial begin

        // Initialize signals
        clk = 0;
        en = 0;
        addr = 0;

        // Wait before enabling
        #10;
        en = 1;

        // Test all 32 addresses
        for (i = 0; i < 32; i = i + 1) begin
            addr = i;
            #10; // Wait for data to stabilize
        end

        #10;
        $finish;
    end

endmodule