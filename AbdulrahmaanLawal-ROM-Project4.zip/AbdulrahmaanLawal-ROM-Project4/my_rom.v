/*
Name: Abdulrahmaan Lawal
RNumber: R111914753
Assignment: Project 4 ROM
*/

`timescale 1ns / 1ps

// this is my ROM module that instantiates the ROM IP core


module my_rom (
    input clk,
    input en,
    input [4:0] addr,
    output [3:0] data_out
);
    ROM rom_inst (
        .clka(clk),
        .ena(en),
        .addra(addr),
        .douta(data_out)
    );
endmodule
