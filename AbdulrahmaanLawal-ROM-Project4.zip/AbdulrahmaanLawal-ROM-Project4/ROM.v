`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    03:33:46 04/20/2026 
// Design Name: 
// Module Name:    ROM 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module ROM(
input clk,
    input en,
    input [4:0] addr,
    output [3:0] data_out
);

    // Instantiate the Xilinx ROM core
    ROM rom_inst (
        .clka(clk),
        .ena(en),
        .addra(addr),
        .douta(data_out)
    );


endmodule
